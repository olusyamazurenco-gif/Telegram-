def hello():
    return "Привет! Это твой Hello World модуль"
